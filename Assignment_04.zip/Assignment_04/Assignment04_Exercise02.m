% Read the image
I = imread('Banana_Orange.PNG');

% Convert image to HSV color space
I_hsv = rgb2hsv(I);

% Define color thresholds for banana (yellow) and orange
banana_mask = (I_hsv(:,:,1) >= 0.10) & (I_hsv(:,:,1) <= 0.20); % Adjusted for yellow
orange_mask = (I_hsv(:,:,1) >= 0.01) & (I_hsv(:,:,1) <= 0.10); % Adjusted for orange

% Remove small noise
banana_mask = bwareaopen(banana_mask, 1500);
orange_mask = bwareaopen(orange_mask, 1500);

% Label connected components
[banana_labels, num_bananas] = bwlabel(banana_mask);
[orange_labels, num_oranges] = bwlabel(orange_mask);

% Get region properties
banana_stats = regionprops(banana_labels, 'Centroid', 'Area');
orange_stats = regionprops(orange_labels, 'Centroid', 'Area');

% Display the original image
imshow(I);
hold on;

% Find and label the largest banana
if num_bananas > 0
    [~, max_idx] = max([banana_stats.Area]); % Find largest banana
    centroid = banana_stats(max_idx).Centroid;
    text(centroid(1), centroid(2), 'Banana', 'Color', 'y', 'FontSize', 14, 'FontWeight', 'bold', 'HorizontalAlignment', 'center');
end

% Find and label the largest orange
if num_oranges > 0
    [~, max_idx] = max([orange_stats.Area]); % Find largest orange
    centroid = orange_stats(max_idx).Centroid;
    text(centroid(1), centroid(2), 'Orange', 'Color', 'r', 'FontSize', 14, 'FontWeight', 'bold', 'HorizontalAlignment', 'center');
end

hold off;

