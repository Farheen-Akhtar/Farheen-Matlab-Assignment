I = imread('Ass4Image1.PNG');

if size(I, 3) == 3
    I = rgb2gray(I);
end

[centers, radii, metric] = imfindcircles(I, [20 100], 'Sensitivity', 0.92);

if ~isempty(radii)
    [~, idx] = max(radii);
    largest_center = centers(idx, :);
    largest_radius = radii(idx);

    imshow(I);
    hold on;
    viscircles(largest_center, largest_radius, 'EdgeColor', 'r', 'LineWidth', 2);
    hold off;
else
    disp('No circles detected.');
end
