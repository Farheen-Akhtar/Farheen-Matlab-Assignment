I = imread("coins.PNG");
imhist(I);
level = graythresh(I);
BW = im2bw(I,level);
imshow(BW);